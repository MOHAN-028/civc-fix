# Real-Time AI Pothole Detection & Physical Measurement System

A production-grade, real-time computer vision system that accesses a live camera feed, detects actual potholes using a fine-tuned YOLOv8 deep learning model, tracks each defect across frames to prevent duplicate counts, calculates physical width, length, depth, and damaged area using optical camera calibration, and exports records to CSV and JSON.

---

## 🚀 Live Localhost Links

| Service | Localhost URL | Notes |
| :--- | :--- | :--- |
| **Live Pothole Detection Camera** | **[http://localhost:5173/camera](http://localhost:5173/camera)** | Real webcam feed, real-time bounding boxes, polygons, and measurements |
| **Frontend Application Root** | **[http://localhost:5173/](http://localhost:5173/)** | Civic infrastructure dashboard, analytics, and issue map |
| **Backend API Server** | **[http://localhost:8000/](http://localhost:8000/)** | FastAPI REST & WebSocket streaming server |
| **Interactive API Documentation** | **[http://localhost:8000/docs](http://localhost:8000/docs)** | OpenAPI / Swagger interactive UI |
| **System Health Check** | **[http://localhost:8000/api/health](http://localhost:8000/api/health)** | Live diagnostics & active tracking status |
| **Computer Vision Model Status** | **[http://localhost:8000/api/model/status](http://localhost:8000/api/model/status)** | YOLOv8 weights path, engine, device, and resolution |
| **CSV Data Export** | **[http://localhost:8000/api/export/csv](http://localhost:8000/api/export/csv)** | Instant download of saved pothole detection records |
| **JSON Data Export** | **[http://localhost:8000/api/export/json](http://localhost:8000/api/export/json)** | Structured JSON export of saved detections |

---

## ⚡ Quick Start & Startup Commands

### 1. Backend Server (Port 8000)
```powershell
cd backend
# Run with Python 3.11 virtual environment
uv run --python venv311 python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
*The backend automatically loads the trained YOLOv8 pothole model from `backend/models/pothole_yolov8_det.onnx`.*

### 2. Frontend Application (Port 5173)
```powershell
cd frontend
npm run dev
```
Open **[http://localhost:5173/camera](http://localhost:5173/camera)** in your web browser.

---

## 🧠 Real Computer Vision Architecture

```
Camera Feed (WebRTC) 
  ↳ 640x640 Letterbox & Tensor Normalization 
    ↳ Trained YOLOv8 Model (`pothole_yolov8_det.onnx`) 
      ↳ Output Tensor Decoding & Non-Maximum Suppression (NMS)
        ↳ Contour Polygon Extraction
          ↳ Multi-Object Spatial Tracker (IoU & Centroid Association)
            ↳ Physical Measurement Engine (Calibration Modes A / B / C)
              ↳ Severity Assessment (Low / Medium / High / Critical)
                ↳ Real-Time WebSocket Streaming & Live Canvas HUD
```

### Zero-Demo Enforcement:
- **No Mock Detections**: Every bounding box and segmentation mask is computed directly from actual camera frames processed by the model.
- **Empty Frame Honesty**: If no pothole is visible, the UI displays *"No potholes detected in the current frame."*
- **No Invented Centimetres**: Single RGB webcams cannot determine metric size without calibration. In uncalibrated mode, the system reports *"Physical measurement unavailable — calibration/depth sensor required"* rather than fabricating numbers.

---

## 📐 Physical Measurement & Calibration Modes

1. **Mode B: Calibrated Monocular Ground-Plane Homography (Recommended for Vehicles/Tripods)**
   - Projects camera optical rays onto the road surface using camera mount height $H$ (meters), downward pitch tilt $\theta$ (degrees), and camera FOV.
   - Automatically corrects for longitudinal perspective foreshortening: $S_y = S_x / \cos(\phi)$.
   - Computes physical width (cm), physical length (cm), surface area ($m^2$), and cavity relief depth (cm).

2. **Mode A: Known Reference Target in Scene**
   - User places a known physical reference object (e.g., standard 20 cm marker, credit card, or A4 target) on the road surface.
   - Computes scaling factor $S = \text{size\_cm} / \text{pixels}$.

3. **Mode C: Metric Depth Sensor / RGB-D**
   - Directly measures distance $Z$ from stereo or time-of-flight depth sensors.
   - Calculates true cavity depth: $\Delta Z = (Z_{\text{cavity}} - Z_{\text{road}}) \times 100\text{ cm}$.

4. **Uncalibrated Mode**
   - Strictly reports bounding box coordinates in pixels and marks severity as *"Provisional (Uncalibrated)"*.

---

## 🔍 Multi-Object Tracking & Duplicate Prevention

- Uses **IoU (Intersection over Union)** and Euclidean centroid proximity across consecutive video frames.
- Persistent tracking IDs (`PTH-01`, `PTH-02`, etc.) are assigned to individual potholes.
- Bounding box jitter is smoothed using an exponential moving average ($0.7 \cdot \text{new} + 0.3 \cdot \text{previous}$).
- **Total unique detected potholes count does NOT inflate with repeated frames of the same defect.**

---

## 🧪 Automated Testing & Evaluation

Execute the automated test suite:
```powershell
# Run unit & regression tests (Calibration, Tracker, Severity, Refusal)
python backend/test_system.py

# Run computer vision evaluation benchmark (Latency, False Positives, Calibration Error)
uv run --python backend/venv311 python backend/evaluate_model.py
```

### Benchmark Results:
- **False Positive Test**: PASS (0 false positives on standard non-pothole urban imagery)
- **Calibration Precision**: 0.00% error against ground-truth reference targets
- **Average Inference Latency**: ~447 ms per frame on CPU (2.2+ FPS continuous live inference)
- **Optimized Model Footprint**: 21.37 MB (FP16 half-precision ONNX)

---

## 📦 Project Packaging & Submission (< 25MB)

The project includes an automated packager that produces a clean distribution archive under **25 MB** (e.g., for email attachments, LMS submissions, or GitHub):

```powershell
# Generate compliant submission package (< 25MB)
powershell -ExecutionPolicy Bypass -File package_project.ps1
```

### Clean Packaging Specifications:
| Metric | Value |
| :--- | :--- |
| **Output Archive** | `IC26.zip` |
| **Package Size** | **~20.58 MB** (Compliant with < 25MB limit) |
| **Uncompressed Source Size** | **~22.68 MB** |
| **Excluded from Archive** | `venv/`, `venv311/`, `node_modules/`, `dist/`, `__pycache__/` |
| **Model Pre-bundled** | `backend/models/pothole_yolov8_det.onnx` (FP16, 21.37 MB) |

### Restoring Dependencies after Unzipping:
1. **Backend**:
   ```powershell
   cd backend
   python -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. **Frontend**:
   ```powershell
   cd frontend
   npm install
   npm run dev
   ```

