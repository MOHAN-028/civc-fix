# Automated Project Packaging Script
# Generates a lightweight distribution ZIP package under 25MB compliant with submission limits.

param (
    [string]$OutputFile = "IC26.zip"
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
if (-not $root) { $root = (Get-Location).Path }

Write-Host "Starting project compression from: $root" -ForegroundColor Cyan

# Define exclusions: virtualenvs, node_modules, caches, and build artifacts
$excludeDirs = @('venv', 'venv311', 'node_modules', '.git', '__pycache__', 'dist', '.vite')
$excludeExtensions = @('.zip', '.bak', '.tmp', '.pyc', '.pyo')

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$tempZip = Join-Path $root "temp_package.zip"
if (Test-Path $tempZip) { Remove-Item $tempZip -Force }

$zip = [System.IO.Compression.ZipFile]::Open($tempZip, [System.IO.Compression.ZipArchiveMode]::Create)

$allFiles = Get-ChildItem -Path $root -Recurse -File

$includedCount = 0
$totalBytes = 0

foreach ($file in $allFiles) {
    $rel = $file.FullName.Substring($root.Length).TrimStart('\', '/')
    $parts = $rel.Split([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
    
    $skip = $false
    foreach ($p in $parts) {
        if ($excludeDirs -contains $p) {
            $skip = $true
            break
        }
    }
    
    $ext = $file.Extension.ToLower()
    if ($excludeExtensions -contains $ext -or $file.Name -eq "temp_package.zip") {
        $skip = $true
    }
    
    if (-not $skip) {
        $entryName = "IC26/" + $rel.Replace('\', '/')
        try {
            $fileStream = [System.IO.File]::Open($file.FullName, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
            $entry = $zip.CreateEntry($entryName, [System.IO.Compression.CompressionLevel]::Optimal)
            $entryStream = $entry.Open()
            $fileStream.CopyTo($entryStream)
            $entryStream.Dispose()
            $fileStream.Dispose()
            $includedCount++
            $totalBytes += $file.Length
        } catch {
            Write-Warning "Could not read file: $($file.FullName) - $_"
        }
    }
}

$zip.Dispose()

$finalDest = Join-Path $root $OutputFile
if (Test-Path $finalDest) {
    Remove-Item $finalDest -Force
}
Move-Item $tempZip $finalDest -Force

$resultFile = Get-Item $finalDest
$sizeMB = [math]::Round($resultFile.Length / 1MB, 2)

Write-Host "==========================================================" -ForegroundColor Green
Write-Host " Successfully generated $OutputFile" -ForegroundColor Green
Write-Host " Included Files:  $includedCount" -ForegroundColor Green
Write-Host " Uncompressed:    $([math]::Round($totalBytes / 1MB, 2)) MB" -ForegroundColor Green
Write-Host " ZIP Package Size:$sizeMB MB" -ForegroundColor Green
Write-Host " Status:          $(if ($sizeMB -le 25.0) { 'PASS (< 25MB)' } else { 'FAIL (> 25MB)' })" -ForegroundColor $(if ($sizeMB -le 25.0) { 'Green' } else { 'Red' })
Write-Host "==========================================================" -ForegroundColor Green
