import os
import io
import time
import shutil
import hashlib
import json
import base64
import csv
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from fastapi import (
    FastAPI, Depends, HTTPException, status, UploadFile, File, Form, Query,
    WebSocket, WebSocketDisconnect, Response
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from jose import jwt, JWTError
from pydantic import BaseModel

from config import settings
from database import (
    get_db, create_tables, User, Report, Detection, StatusHistory,
    UserRole, ReportStatus, SeverityLevel, ProblemCategory
)
from pothole_detector import real_detector
from tracker import pothole_tracker
from calibration_measurement import measurement_engine

# Ensure required directories exist
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs("models", exist_ok=True)

# Create database tables
create_tables()

app = FastAPI(
    title="Real-Time AI Pothole Detection & Measurement Platform",
    description="Live camera computer vision pothole detection, spatial tracking, and physical measurement system.",
    version="2.5.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files for snapshots
app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")

security = HTTPBearer(auto_error=False)

def hash_password(password: str) -> str:
    return hashlib.sha256((password + settings.SECRET_KEY).encode()).hexdigest()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return hash_password(plain_password) == hashed_password

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: Session = Depends(get_db)
) -> Optional[User]:
    if not credentials:
        return None
    try:
        payload = jwt.decode(credentials.credentials, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id: int = payload.get("sub")
        if user_id is None:
            return None
    except JWTError:
        return None
    user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
    return user

# ── Seed Initial Data ──────────────────────────────────────────────────
@app.on_event("startup")
def seed_initial_data():
    db = next(get_db())
    try:
        # Seed default administrative & testing accounts if empty
        if db.query(User).count() == 0:
            demo_users = [
                User(name="Field Inspector", email="inspector@civicfix.ai", hashed_password=hash_password("password123"), role=UserRole.officer.value, ward="Central Ward"),
                User(name="Road Maintenance Lead", email="maintenance@civicfix.ai", hashed_password=hash_password("password123"), role=UserRole.maintenance.value, ward="Division 4"),
                User(name="System Administrator", email="admin@civicfix.ai", hashed_password=hash_password("password123"), role=UserRole.admin.value, ward="Central HQ"),
                User(name="Citizen Reporter", email="citizen@civicfix.ai", hashed_password=hash_password("password123"), role=UserRole.citizen.value, ward="Ward 12"),
            ]
            db.add_all(demo_users)
            db.commit()
    finally:
        db.close()

# ── Pydantic Request Schemas ──────────────────────────────────────────
class LoginRequest(BaseModel):
    email: str
    password: str

class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    role: Optional[str] = "citizen"
    ward: Optional[str] = None

class ProcessFrameRequest(BaseModel):
    frame: str  # Base64 data URL or raw base64
    calibration: Optional[Dict[str, Any]] = None
    sensitivity: Optional[str] = "medium"

class SaveDetectionRequest(BaseModel):
    tracking_id: str
    class_name: Optional[str] = "Pothole"
    category: Optional[str] = "Road Damage"
    severity: Optional[str] = "Medium"
    confidence: float
    physical_width: Optional[float] = None
    physical_length: Optional[float] = None
    surface_area: Optional[float] = None
    estimated_depth: Optional[str] = None
    measurement_method: Optional[str] = None
    measurement_confidence: Optional[str] = None
    measurement_uncertainty: Optional[str] = None
    segmentation_points: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    gps_accuracy: Optional[float] = None
    address: Optional[str] = None
    ward: Optional[str] = None
    description: Optional[str] = None
    image_base64: Optional[str] = None

class DetectionStatusUpdateRequest(BaseModel):
    status: Optional[str] = None
    assigned_dept: Optional[str] = None
    note: Optional[str] = None

# ── Health & Diagnostics Endpoints ─────────────────────────────────────
@app.get("/api/health")
def health_check():
    model_status = real_detector.get_status()
    return {
        "status": "healthy",
        "app": "Real-Time AI Pothole Detection and Measurement System",
        "timestamp": datetime.utcnow().isoformat(),
        "model_loaded": model_status["is_loaded"],
        "model_architecture": model_status["architecture"],
        "backend_engine": model_status["backend_engine"],
        "device": model_status["device"],
        "active_tracks_count": len(pothole_tracker.tracks),
        "total_unique_detected": pothole_tracker.total_unique_detected,
        "calibration_modes": [
            "uncalibrated",
            "mode_a_reference",
            "mode_b_ground_plane",
            "mode_c_depth_sensor"
        ]
    }

@app.get("/api/model/status")
def model_status_endpoint():
    """Returns verified model availability, weights file, device, and readiness."""
    return real_detector.get_status()

# ── Authentication Endpoints ───────────────────────────────────────────
@app.post("/api/auth/register")
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == req.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="User with this email already exists")

    new_user = User(
        name=req.name,
        email=req.email,
        hashed_password=hash_password(req.password),
        role=req.role or UserRole.citizen.value,
        ward=req.ward
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    token = create_access_token({"sub": new_user.id, "email": new_user.email, "role": new_user.role})
    return {
        "token": token,
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": new_user.id,
            "name": new_user.name,
            "email": new_user.email,
            "role": new_user.role,
            "ward": new_user.ward
        }
    }

@app.post("/api/auth/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email).first()
    if not user or not verify_password(req.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": user.id, "email": user.email, "role": user.role})
    return {
        "token": token,
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role,
            "ward": user.ward
        }
    }

@app.get("/api/auth/me")
def get_me(user: Optional[User] = Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "ward": user.ward
    }

# ── Core Real-Time Detection & Measurement WebSocket ───────────────────
def process_frame_internal(
    image_bytes: bytes,
    calibration: Dict[str, Any],
    sensitivity: str = "medium"
) -> Dict[str, Any]:
    """
    Genuine computer vision frame processing pipeline:
    1. Real Model Inference (YOLOv8)
    2. Multi-Object Spatial Tracking (prevents duplicate counting)
    3. Physical Measurement & Geometry Calibration
    4. Severity Classification
    5. Honest status generation (Zero fake detections)
    """
    # Sensitivity confidence threshold
    conf_thresh = 0.20 if sensitivity == "high" else (0.28 if sensitivity == "medium" else 0.40)

    # Step 1: Real Pothole Inference
    raw_detections, latency_ms, orig_w, orig_h = real_detector.detect_potholes(
        image_bytes,
        conf_threshold=conf_thresh,
        iou_threshold=0.45
    )

    # Step 2: Multi-Object Tracking across consecutive frames
    active_tracks, new_count, total_unique = pothole_tracker.update(raw_detections)

    # Step 3: Physical Measurement Engine
    processed_detections = []
    severity_breakdown = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}

    for track in active_tracks:
        meas = measurement_engine.calculate_measurements(
            bbox=track.bbox,
            polygon=track.polygon,
            image_w=orig_w,
            image_h=orig_h,
            calibration=calibration
        )
        track.measurements = meas
        sev = meas["severity"]
        # Normalize severity key for breakdown
        clean_sev = "Critical" if "Critical" in sev else ("High" if "High" in sev else ("Medium" if "Medium" in sev else "Low"))
        severity_breakdown[clean_sev] += 1

        processed_detections.append({
            "tracking_id": track.track_id,
            "class_name": track.class_name,
            "category": "Road Damage",
            "confidence": track.conf,
            "best_confidence": track.best_conf,
            "hits": track.hits,
            "bbox": track.bbox,
            "polygon": track.polygon,
            "severity": sev,
            "measurements": {
                "physical_width": meas["physical_width_cm"],
                "physical_length": meas["physical_length_cm"],
                "surface_area": meas["surface_area_m2"],
                "surface_area_cm2": meas["surface_area_cm2"],
                "estimated_depth": meas["depth_status"],
                "depth_cm": meas["physical_depth_cm"],
                "measurement_method": meas["measurement_method"],
                "confidence_rating": meas["measurement_confidence"],
                "uncertainty": meas["measurement_uncertainty"],
                "measurement_status": meas["measurement_status"],
                "is_calibrated": meas["is_calibrated"],
                "pixel_dimensions": {
                    "width_px": meas["pixel_width"],
                    "height_px": meas["pixel_length"],
                    "area_px": meas["pixel_area"]
                }
            },
            "action": "Asphalt cavity excavation and hot-mix bituminous patch repair.",
            "dept": "Roads & Highways Department"
        })

    return {
        "status": "success",
        "has_detections": len(processed_detections) > 0,
        "detection_message": f"{len(processed_detections)} pothole(s) detected in current frame" if processed_detections else "No potholes detected in the current frame.",
        "detections": processed_detections,
        "frame_dimensions": {"width": orig_w, "height": orig_h},
        "latency_ms": latency_ms,
        "model_status": {
            "loaded": real_detector.is_loaded,
            "engine": real_detector.backend_engine,
            "device": real_detector.device
        },
        "session_summary": {
            "total_unique_potholes": total_unique,
            "currently_visible": len(processed_detections),
            "new_detections": new_count,
            "persisted_potholes": len(processed_detections) - new_count,
            "severity_breakdown": severity_breakdown
        }
    }

@app.websocket("/api/ws/live-detect")
@app.websocket("/ws/detect")
async def websocket_live_detect(websocket: WebSocket):
    """
    Continuous real-time frame detection via WebSocket.
    Processes actual incoming camera frames from the user's browser.
    """
    await websocket.accept()
    try:
        while True:
            text_data = await websocket.receive_text()
            msg = json.loads(text_data)
            frame_b64 = msg.get("frame")
            calibration = msg.get("calibration", {})
            sensitivity = msg.get("sensitivity", "medium")

            if frame_b64:
                if "," in frame_b64:
                    frame_b64 = frame_b64.split(",")[1]
                image_bytes = base64.b64decode(frame_b64)

                result = process_frame_internal(
                    image_bytes=image_bytes,
                    calibration=calibration,
                    sensitivity=sensitivity
                )
                await websocket.send_text(json.dumps(result))
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await websocket.close()
        except Exception:
            pass

# HTTP endpoint fallback for frame processing
@app.post("/api/camera/process-frame")
def process_frame_http(req: ProcessFrameRequest):
    frame_b64 = req.frame
    if "," in frame_b64:
        frame_b64 = frame_b64.split(",")[1]
    image_bytes = base64.b64decode(frame_b64)

    result = process_frame_internal(
        image_bytes=image_bytes,
        calibration=req.calibration or {},
        sensitivity=req.sensitivity or "medium"
    )
    return result

# Reset session tracking endpoint
@app.post("/api/session/reset")
def reset_session():
    pothole_tracker.reset_session()
    return {
        "success": True,
        "message": "Tracking session reset. Unique pothole counter initialized to 0.",
        "total_unique_detected": 0
    }

# ── Uploaded Image Detection Endpoint ──────────────────────────────────
@app.post("/api/detect")
@app.post("/api/detect/image")
async def detect_image(
    file: Optional[UploadFile] = File(None),
    image: Optional[UploadFile] = File(None),
    calibration_mode: Optional[str] = Form("uncalibrated"),
    camera_height: Optional[float] = Form(1.2),
    camera_tilt: Optional[float] = Form(45.0),
    reference_size_cm: Optional[float] = Form(20.0),
    reference_px: Optional[float] = Form(100.0)
):
    target = file or image
    if not target:
        raise HTTPException(status_code=400, detail="Image file must be provided")

    content = await target.read()
    
    calib = {
        "mode": calibration_mode,
        "camera_height_m": camera_height,
        "camera_tilt_deg": camera_tilt,
        "reference_object_size_cm": reference_size_cm,
        "reference_object_px": reference_px
    }

    result = process_frame_internal(content, calibration=calib, sensitivity="medium")
    return {
        "success": True,
        "filename": target.filename,
        "processing_time_ms": result["latency_ms"],
        "detections_count": len(result["detections"]),
        "detections": result["detections"],
        "session_summary": result["session_summary"],
        "model_status": result["model_status"]
    }

# ── Save Detection Evidence & Create Official Civic Record ─────────────
@app.post("/api/detections")
@app.post("/api/camera/save-evidence")
def save_detection(
    req: SaveDetectionRequest,
    user: Optional[User] = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Saves an actual detection record to the database.
    Stores real measurements, tracking ID, timestamp, and optional GPS coordinates.
    """
    image_rel_path = None
    if req.image_base64:
        raw_b64 = req.image_base64
        if "," in raw_b64:
            raw_b64 = raw_b64.split(",")[1]
        img_bytes = base64.b64decode(raw_b64)
        filename = f"pothole_{req.tracking_id}_{int(time.time())}.jpg"
        save_path = os.path.join(settings.UPLOAD_DIR, filename)
        with open(save_path, "wb") as f:
            f.write(img_bytes)
        image_rel_path = f"/uploads/{filename}"

    count = db.query(Report).count() + 1
    report_id = f"CF-2026-{count:05d}"

    rep = Report(
        report_id=report_id,
        reporter_id=user.id if user else None,
        category="Road Damage",
        subtype=req.class_name or "Pothole",
        severity=req.severity or "Medium",
        status="Awaiting Review",
        confidence_score=req.confidence,
        
        # Geolocation (Real coordinates when granted)
        latitude=req.latitude,
        longitude=req.longitude,
        gps_accuracy=req.gps_accuracy,
        address=req.address or ("GPS Geolocation Coordinates Recorded" if req.latitude else "Manual Location Pending"),
        ward=req.ward or "City Central",
        image_path=image_rel_path,
        is_demo=False,
        description=req.description or f"Verified Computer Vision detection of {req.class_name} (Tracking ID: {req.tracking_id}).",
        recommended_action="Emergency cavity backfill and bituminous asphalt overlay required.",
        assigned_dept="Roads & Highways Department",
        
        # Physical metrics
        tracking_id=req.tracking_id,
        physical_width=req.physical_width,
        physical_length=req.physical_length,
        surface_area=req.surface_area,
        estimated_depth=req.estimated_depth,
        measurement_method=req.measurement_method,
        measurement_confidence=req.measurement_confidence,
        measurement_uncertainty=req.measurement_uncertainty,
        segmentation_points=req.segmentation_points
    )
    db.add(rep)
    db.commit()
    db.refresh(rep)

    # Add audit history
    history = StatusHistory(
        report_id=rep.id,
        old_status="None",
        new_status=rep.status,
        changed_by_id=user.id if user else None,
        note=f"Recorded via Live Camera Pothole Detection. Tracking ID: {req.tracking_id}."
    )
    db.add(history)
    db.commit()

    return {
        "success": True,
        "id": rep.id,
        "report_id": rep.report_id,
        "tracking_id": rep.tracking_id,
        "status": rep.status,
        "severity": rep.severity,
        "created_at": rep.created_at.isoformat() if rep.created_at else None,
        "message": f"Detection record saved with ID {rep.report_id}."
    }

# ── Retrieve Saved Detection Records ───────────────────────────────────
@app.get("/api/detections")
@app.get("/api/reports")
def list_detections(
    severity: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    q = db.query(Report)
    if severity:
        q = q.filter(Report.severity == severity)
    if status:
        q = q.filter(Report.status == status)
    if search:
        q = q.filter(
            (Report.report_id.ilike(f"%{search}%")) |
            (Report.tracking_id.ilike(f"%{search}%")) |
            (Report.address.ilike(f"%{search}%")) |
            (Report.description.ilike(f"%{search}%"))
        )

    total = q.count()
    records = q.order_by(Report.created_at.desc()).offset(offset).limit(limit).all()

    items = []
    for r in records:
        items.append({
            "id": r.id,
            "report_id": r.report_id,
            "tracking_id": r.tracking_id,
            "category": r.category,
            "subtype": r.subtype,
            "severity": r.severity,
            "status": r.status,
            "confidence_score": r.confidence_score,
            "physical_width": r.physical_width,
            "physical_length": r.physical_length,
            "surface_area": r.surface_area,
            "estimated_depth": r.estimated_depth,
            "measurement_method": r.measurement_method,
            "measurement_confidence": r.measurement_confidence,
            "measurement_uncertainty": r.measurement_uncertainty,
            "latitude": r.latitude,
            "longitude": r.longitude,
            "gps_accuracy": r.gps_accuracy,
            "address": r.address,
            "ward": r.ward,
            "image_path": r.image_path,
            "is_demo": r.is_demo,
            "description": r.description,
            "recommended_action": r.recommended_action,
            "assigned_dept": r.assigned_dept,
            "created_at": r.created_at.isoformat() if r.created_at else None,
            "updated_at": r.updated_at.isoformat() if r.updated_at else None,
        })

    return {"total": total, "items": items, "data": items}

@app.get("/api/reports/{id}")
def get_single_report(id: int, db: Session = Depends(get_db)):
    rep = db.query(Report).filter(Report.id == id).first()
    if not rep:
        raise HTTPException(status_code=404, detail="Detection record not found")
    
    return {
        "id": rep.id,
        "report_id": rep.report_id,
        "tracking_id": rep.tracking_id,
        "category": rep.category,
        "subtype": rep.subtype,
        "severity": rep.severity,
        "status": rep.status,
        "confidence_score": rep.confidence_score,
        "physical_width": rep.physical_width,
        "physical_length": rep.physical_length,
        "surface_area": rep.surface_area,
        "estimated_depth": rep.estimated_depth,
        "measurement_method": rep.measurement_method,
        "measurement_confidence": rep.measurement_confidence,
        "measurement_uncertainty": rep.measurement_uncertainty,
        "latitude": rep.latitude,
        "longitude": rep.longitude,
        "gps_accuracy": rep.gps_accuracy,
        "address": rep.address,
        "ward": rep.ward,
        "image_path": rep.image_path,
        "description": rep.description,
        "recommended_action": rep.recommended_action,
        "assigned_dept": rep.assigned_dept,
        "created_at": rep.created_at.isoformat() if rep.created_at else None,
        "history": [
            {
                "id": h.id,
                "old_status": h.old_status,
                "new_status": h.new_status,
                "note": h.note,
                "created_at": h.created_at.isoformat() if h.created_at else None
            } for h in rep.history
        ]
    }

@app.patch("/api/reports/{id}")
@app.patch("/api/detections/{id}")
def update_detection_status(
    id: int,
    req: DetectionStatusUpdateRequest,
    user: Optional[User] = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    rep = db.query(Report).filter(Report.id == id).first()
    if not rep:
        raise HTTPException(status_code=404, detail="Detection record not found")

    old_status = rep.status
    if req.status and req.status != old_status:
        rep.status = req.status
        history = StatusHistory(
            report_id=rep.id,
            old_status=old_status,
            new_status=req.status,
            changed_by_id=user.id if user else None,
            note=req.note or f"Status changed to {req.status}"
        )
        db.add(history)

    if req.assigned_dept:
        rep.assigned_dept = req.assigned_dept

    db.commit()
    db.refresh(rep)
    return {"success": True, "report_id": rep.report_id, "status": rep.status}

@app.delete("/api/reports/{id}")
@app.delete("/api/detections/{id}")
def delete_detection(id: int, db: Session = Depends(get_db)):
    rep = db.query(Report).filter(Report.id == id).first()
    if not rep:
        raise HTTPException(status_code=404, detail="Detection record not found")
    db.delete(rep)
    db.commit()
    return {"success": True, "message": "Record successfully deleted"}

# ── CSV & JSON Data Export Endpoints ──────────────────────────────────
@app.get("/api/export/csv")
def export_csv(db: Session = Depends(get_db)):
    """Exports all stored pothole detection and measurement records to CSV."""
    records = db.query(Report).order_by(Report.created_at.desc()).all()
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Header row
    writer.writerow([
        "Record_ID",
        "Tracking_ID",
        "Category",
        "Subtype",
        "Severity",
        "Status",
        "Confidence",
        "Width_cm",
        "Length_cm",
        "Area_m2",
        "Depth",
        "Measurement_Method",
        "Measurement_Confidence",
        "Latitude",
        "Longitude",
        "Address",
        "Ward",
        "Created_At"
    ])
    
    for r in records:
        writer.writerow([
            r.report_id,
            r.tracking_id or "",
            r.category,
            r.subtype or "",
            r.severity,
            r.status,
            f"{r.confidence_score:.2f}" if r.confidence_score is not None else "",
            r.physical_width if r.physical_width is not None else "",
            r.physical_length if r.physical_length is not None else "",
            r.surface_area if r.surface_area is not None else "",
            r.estimated_depth or "",
            r.measurement_method or "Uncalibrated",
            r.measurement_confidence or "",
            r.latitude if r.latitude is not None else "",
            r.longitude if r.longitude is not None else "",
            r.address or "",
            r.ward or "",
            r.created_at.isoformat() if r.created_at else ""
        ])
        
    output.seek(0)
    response = StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv"
    )
    response.headers["Content-Disposition"] = "attachment; filename=pothole_detections_export.csv"
    return response

@app.get("/api/export/json")
def export_json(db: Session = Depends(get_db)):
    """Exports all stored pothole detection and measurement records to JSON."""
    records = db.query(Report).order_by(Report.created_at.desc()).all()
    data = []
    for r in records:
        data.append({
            "report_id": r.report_id,
            "tracking_id": r.tracking_id,
            "category": r.category,
            "subtype": r.subtype,
            "severity": r.severity,
            "status": r.status,
            "confidence_score": r.confidence_score,
            "physical_measurements": {
                "width_cm": r.physical_width,
                "length_cm": r.physical_length,
                "surface_area_m2": r.surface_area,
                "estimated_depth": r.estimated_depth,
                "method": r.measurement_method,
                "confidence": r.measurement_confidence,
                "uncertainty": r.measurement_uncertainty
            },
            "gps_coordinates": {
                "latitude": r.latitude,
                "longitude": r.longitude,
                "accuracy_m": r.gps_accuracy
            },
            "address": r.address,
            "ward": r.ward,
            "created_at": r.created_at.isoformat() if r.created_at else None
        })

    response = Response(
        content=json.dumps(data, indent=2),
        media_type="application/json"
    )
    response.headers["Content-Disposition"] = "attachment; filename=pothole_detections_export.json"
    return response

# Stats endpoint for dashboard
@app.get("/api/reports/stats")
def get_stats(db: Session = Depends(get_db)):
    total = db.query(Report).count()
    resolved = db.query(Report).filter(Report.status == "Resolved").count()
    in_progress = db.query(Report).filter(Report.status.in_(["In Progress", "Assigned"])).count()
    pending = db.query(Report).filter(Report.status.in_(["Awaiting Review", "Detected", "Submitted"])).count()
    critical = db.query(Report).filter(Report.severity == "Critical").count()

    return {
        "total": total,
        "resolved": resolved,
        "in_progress": in_progress,
        "pending": pending,
        "critical_alerts": critical,
        "model_status": real_detector.get_status(),
        "active_session": {
            "total_unique": pothole_tracker.total_unique_detected,
            "active_tracks": len(pothole_tracker.tracks)
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
