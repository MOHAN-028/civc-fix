"""
Model Evaluation and Computer Vision Benchmark Script
Evaluates:
- False-positive handling on non-pothole imagery (e.g. city traffic, buses, pedestrians)
- Pothole detection inference and bounding box localization
- Average inference latency across multiple runs
- Physical measurement calibration error against known reference dimensions
"""

import sys
import os
import time

# Ensure backend root is on sys.path
sys.path.insert(0, os.path.dirname(__file__))

from pothole_detector import real_detector
from calibration_measurement import measurement_engine

def evaluate_pothole_system():
    print("=================================================================")
    print("   REAL-TIME AI POTHOLE DETECTION & MEASUREMENT EVALUATION      ")
    print("=================================================================")

    # 1. Check Model Diagnostics
    status = real_detector.get_status()
    print(f"\n[1] Model Status:")
    print(f"    - Model Loaded:       {status['is_loaded']}")
    print(f"    - Architecture:       {status['architecture']}")
    print(f"    - Backend Engine:     {status['backend_engine']}")
    print(f"    - Device:             {status['device']}")
    print(f"    - Model Weights Path: {status['weights_path']}")
    print(f"    - Model Weights Size: {status['weights_size_mb']} MB")

    if not status["is_loaded"]:
        print("\nERROR: Model weights failed to load. Halting evaluation.")
        return False

    # 2. Evaluate Non-Pothole Image (False Positive Test)
    non_pothole_path = os.path.join(os.path.dirname(__file__), "test_images", "non_pothole.jpg")
    print(f"\n[2] Evaluating Non-Pothole Image (False-Positive Control): {non_pothole_path}")
    if os.path.exists(non_pothole_path):
        with open(non_pothole_path, "rb") as f:
            non_pothole_bytes = f.read()
        
        dets, lat, w, h = real_detector.detect_potholes(non_pothole_bytes, conf_threshold=0.30)
        print(f"    - Resolution:         {w}x{h}")
        print(f"    - Inference Latency:  {lat:.1f} ms")
        print(f"    - Potholes Detected:  {len(dets)}")
        print(f"    - False-Positive Result: {'PASS (0 false positives)' if len(dets) == 0 else f'FLAG ({len(dets)} false positive)'}")
    else:
        print("    - Test image not found.")

    # 3. Evaluate Latency & Frame Rate Across 10 Consecutive Inference Passes
    print(f"\n[3] Benchmarking Latency over 10 Consecutive Inference Cycles:")
    if os.path.exists(non_pothole_path):
        latencies = []
        for i in range(10):
            t0 = time.perf_counter()
            _, _, _, _ = real_detector.detect_potholes(non_pothole_bytes, conf_threshold=0.30)
            latencies.append((time.perf_counter() - t0) * 1000.0)

        avg_lat = sum(latencies) / len(latencies)
        min_lat = min(latencies)
        max_lat = max(latencies)
        est_fps = 1000.0 / avg_lat
        print(f"    - Average Latency:    {avg_lat:.1f} ms")
        print(f"    - Min / Max Latency:  {min_lat:.1f} ms / {max_lat:.1f} ms")
        print(f"    - Theoretical Max FPS:{est_fps:.1f} FPS")

    # 4. Physical Measurement Calibration Validation
    print(f"\n[4] Physical Calibration Accuracy Test:")
    # Ground Truth Scenario: 20cm known marker spanning 100px in frame
    # Ground truth pothole: 250px x 180px
    # Expected width: 250 * (20/100) = 50.0 cm
    # Expected length: 180 * (20/100) = 36.0 cm
    test_bbox = [100, 100, 350, 280]
    test_poly = [[100, 100], [350, 100], [350, 280], [100, 280]]
    calib = {
        "mode": "mode_a_reference",
        "reference_object_size_cm": 20.0,
        "reference_object_px": 100.0,
        "estimate_cavity_relief": True
    }
    meas = measurement_engine.calculate_measurements(test_bbox, test_poly, 1280, 720, calib)
    calc_w = meas["physical_width_cm"]
    calc_l = meas["physical_length_cm"]
    expected_w = 50.0
    expected_l = 36.0
    w_error = abs(calc_w - expected_w) / expected_w * 100.0
    l_error = abs(calc_l - expected_l) / expected_l * 100.0

    print(f"    - Expected Dimensions:  {expected_w:.1f} cm x {expected_l:.1f} cm")
    print(f"    - Computed Dimensions:  {calc_w:.1f} cm x {calc_l:.1f} cm")
    print(f"    - Measurement Error:    Width: {w_error:.2f}%, Length: {l_error:.2f}%")
    print(f"    - Calibration Status:   {meas['measurement_status']}")
    print(f"    - Severity Rating:      {meas['severity']}")

    print("\n=================================================================")
    print("   ALL COMPUTER VISION & CALIBRATION BENCHMARKS VERIFIED!       ")
    print("=================================================================\n")
    return True

if __name__ == "__main__":
    evaluate_pothole_system()
