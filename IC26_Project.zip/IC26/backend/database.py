from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.sql import func
import enum
from config import settings

connect_args = {"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}
engine = create_engine(
    settings.DATABASE_URL,
    connect_args=connect_args,
    pool_pre_ping=False if "sqlite" in settings.DATABASE_URL else True
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ── Enums ──────────────────────────────────────────────────────────────
class UserRole(str, enum.Enum):
    citizen = "citizen"
    officer = "officer"
    maintenance = "maintenance"
    admin = "admin"

class ReportStatus(str, enum.Enum):
    detected = "Detected"
    awaiting_review = "Awaiting Review"
    submitted = "Submitted"
    verified = "Verified"
    assigned = "Assigned"
    in_progress = "In Progress"
    resolved = "Resolved"
    rejected = "Rejected"

class SeverityLevel(str, enum.Enum):
    critical = "Critical"
    high = "High"
    medium = "Medium"
    low = "Low"

class ProblemCategory(str, enum.Enum):
    road = "Road Damage"
    drainage = "Drainage"
    streetlight = "Streetlight"
    other = "Public Infrastructure"

# ── Models ──────────────────────────────────────────────────────────────
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(50), default=UserRole.citizen.value, nullable=False)
    phone = Column(String(20))
    ward = Column(String(100))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    reports = relationship("Report", back_populates="reporter", foreign_keys="Report.reporter_id")

class Report(Base):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True, index=True)
    report_id = Column(String(20), unique=True, index=True)  # e.g. CF-2026-00001
    reporter_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    category = Column(String(50), nullable=False)
    subtype = Column(String(100))
    description = Column(Text)
    severity = Column(String(50), default=SeverityLevel.medium.value)
    status = Column(String(50), default=ReportStatus.detected.value)
    confidence_score = Column(Float, default=0.0)
    
    # Geolocation
    latitude = Column(Float)
    longitude = Column(Float)
    gps_accuracy = Column(Float, default=5.0)
    address = Column(Text)
    ward = Column(String(100))
    image_path = Column(String(500))
    is_demo = Column(Boolean, default=False)
    recommended_action = Column(Text)
    assigned_dept = Column(String(100))
    assigned_to_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    # Real-time measurement & tracking additions
    tracking_id = Column(String(50), index=True)
    physical_width = Column(Float, nullable=True)     # cm or m
    physical_length = Column(Float, nullable=True)    # cm or m
    surface_area = Column(Float, nullable=True)       # m² or cm²
    estimated_depth = Column(String(100), nullable=True)
    measurement_method = Column(String(100), nullable=True)
    measurement_confidence = Column(String(50), nullable=True)
    measurement_uncertainty = Column(String(50), nullable=True)
    segmentation_points = Column(Text, nullable=True) # JSON coordinates
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    reporter = relationship("User", back_populates="reports", foreign_keys=[reporter_id])
    assigned_to = relationship("User", foreign_keys=[assigned_to_id])
    detections = relationship("Detection", back_populates="report", cascade="all, delete-orphan")
    history = relationship("StatusHistory", back_populates="report", cascade="all, delete-orphan")

class Detection(Base):
    __tablename__ = "detections"
    id = Column(Integer, primary_key=True, index=True)
    report_id = Column(Integer, ForeignKey("reports.id"))
    tracking_id = Column(String(50), index=True)
    class_name = Column(String(100))
    confidence = Column(Float)
    bbox_x1 = Column(Float)
    bbox_y1 = Column(Float)
    bbox_x2 = Column(Float)
    bbox_y2 = Column(Float)
    severity = Column(String(50))
    
    # Measurements
    physical_width = Column(Float, nullable=True)
    physical_length = Column(Float, nullable=True)
    surface_area = Column(Float, nullable=True)
    estimated_depth = Column(String(100), nullable=True)
    measurement_method = Column(String(100), nullable=True)
    measurement_confidence = Column(String(50), nullable=True)
    segmentation_points = Column(Text, nullable=True)

    is_demo = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    report = relationship("Report", back_populates="detections")

class StatusHistory(Base):
    __tablename__ = "status_history"
    id = Column(Integer, primary_key=True, index=True)
    report_id = Column(Integer, ForeignKey("reports.id"))
    old_status = Column(String(50))
    new_status = Column(String(50))
    changed_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    note = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    report = relationship("Report", back_populates="history")

def create_tables():
    Base.metadata.create_all(bind=engine)
