"""
Real-time Multi-Object Pothole Tracker
Prevents duplicate counts across consecutive video frames using IoU and Centroid association.
Tracks unique potholes across the entire live inspection session.
"""

import time
import math
from typing import List, Dict, Any, Optional, Tuple, Set

def compute_iou(bb1: List[int], bb2: List[int]) -> float:
    """Computes Intersection over Union (IoU) of two bounding boxes [x1, y1, x2, y2]."""
    x_left = max(bb1[0], bb2[0])
    y_top = max(bb1[1], bb2[1])
    x_right = min(bb1[2], bb2[2])
    y_bottom = min(bb1[3], bb2[3])

    if x_right < x_left or y_bottom < y_top:
        return 0.0

    intersection = (x_right - x_left) * (y_bottom - y_top)
    area1 = (bb1[2] - bb1[0]) * (bb1[3] - bb1[1])
    area2 = (bb2[2] - bb2[0]) * (bb2[3] - bb2[1])
    union = float(area1 + area2 - intersection)
    
    if union <= 0:
        return 0.0
    return max(0.0, min(1.0, intersection / union))

def compute_center_distance(bb1: List[int], bb2: List[int]) -> float:
    """Computes Euclidean distance between centers of two boxes."""
    c1_x = (bb1[0] + bb1[2]) / 2.0
    c1_y = (bb1[1] + bb1[3]) / 2.0
    c2_x = (bb2[0] + bb2[2]) / 2.0
    c2_y = (bb2[1] + bb2[3]) / 2.0
    return math.hypot(c1_x - c2_x, c1_y - c2_y)

class TrackedPothole:
    def __init__(self, track_id: str, bbox: List[int], polygon: List[List[int]], conf: float, class_name: str = "Pothole"):
        self.track_id = track_id
        self.class_name = class_name
        self.bbox = [int(v) for v in bbox]
        self.polygon = polygon
        self.conf = round(float(conf), 3)
        self.best_conf = self.conf
        self.hits = 1
        self.time_since_update = 0
        self.created_at = time.time()
        self.last_seen = time.time()
        self.measurements: Dict[str, Any] = {}

    def update(self, bbox: List[int], polygon: List[List[int]], conf: float):
        # Smoothing alpha for bounding box stability
        alpha = 0.70
        self.bbox = [
            int(self.bbox[0] * (1.0 - alpha) + bbox[0] * alpha),
            int(self.bbox[1] * (1.0 - alpha) + bbox[1] * alpha),
            int(self.bbox[2] * (1.0 - alpha) + bbox[2] * alpha),
            int(self.bbox[3] * (1.0 - alpha) + bbox[3] * alpha),
        ]
        if polygon and len(polygon) >= 3:
            self.polygon = polygon
        self.conf = round(self.conf * 0.3 + float(conf) * 0.7, 3)
        if conf > self.best_conf:
            self.best_conf = round(float(conf), 3)
        self.hits += 1
        self.time_since_update = 0
        self.last_seen = time.time()

class RealPotholeTracker:
    def __init__(self, max_lost_frames: int = 12, min_iou: float = 0.30):
        self.tracks: Dict[str, TrackedPothole] = {}
        self.next_index: int = 1
        self.max_lost_frames: int = max_lost_frames
        self.min_iou: float = min_iou
        self.total_unique_detected: int = 0
        self.session_start: float = time.time()

    def reset_session(self):
        """Resets the tracking session count and active tracks."""
        self.tracks.clear()
        self.next_index = 1
        self.total_unique_detected = 0
        self.session_start = time.time()

    def update(self, raw_detections: List[Dict[str, Any]]) -> Tuple[List[TrackedPothole], int, int]:
        """
        Matches raw detections to existing tracks using IoU & center distance.
        Returns:
            - list of currently active TrackedPothole objects
            - new_detections_count in this frame
            - total_unique_detected in this session
        """
        # Increment age of existing tracks
        for track in list(self.tracks.values()):
            track.time_since_update += 1
            if track.time_since_update > self.max_lost_frames:
                del self.tracks[track.track_id]

        active_track_list = list(self.tracks.values())
        unmatched_detections = list(range(len(raw_detections)))
        matched_tracks = set()
        new_detections_count = 0

        # Match existing tracks with highest IoU
        for det_idx in list(unmatched_detections):
            det = raw_detections[det_idx]
            det_bbox = det["bbox"]
            best_iou = 0.0
            best_track = None

            for track in active_track_list:
                if track.track_id in matched_tracks:
                    continue
                iou = compute_iou(track.bbox, det_bbox)
                # Also check spatial distance if IoU is near edge
                box_diag = math.hypot(det_bbox[2] - det_bbox[0], det_bbox[3] - det_bbox[1])
                dist = compute_center_distance(track.bbox, det_bbox)

                if iou >= self.min_iou or (dist < box_diag * 0.4 and iou > 0.15):
                    if iou > best_iou:
                        best_iou = iou
                        best_track = track

            if best_track is not None:
                best_track.update(det["bbox"], det.get("polygon", []), det["confidence"])
                matched_tracks.add(best_track.track_id)
                unmatched_detections.remove(det_idx)

        # For remaining unmatched detections, spawn new unique tracks
        for det_idx in unmatched_detections:
            det = raw_detections[det_idx]
            track_id = f"PTH-{self.next_index:02d}"
            self.next_index += 1
            self.total_unique_detected += 1
            new_detections_count += 1

            new_track = TrackedPothole(
                track_id=track_id,
                bbox=det["bbox"],
                polygon=det.get("polygon", []),
                conf=det["confidence"],
                class_name=det.get("class_name", "Pothole")
            )
            self.tracks[track_id] = new_track

        # Return active tracks visible in current frame (time_since_update == 0)
        current_active = [t for t in self.tracks.values() if t.time_since_update == 0]
        return current_active, new_detections_count, self.total_unique_detected

pothole_tracker = RealPotholeTracker()
